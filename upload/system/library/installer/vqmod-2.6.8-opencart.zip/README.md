vqmod
=====

The official vQmod repository

Please ensure you download from the RELEASES link above, or here - https://github.com/vqmod/vqmod/releases
The official source code is a stand-alone package. Be sure to also download the script files for your platform (e.g. opencart)

Installation video for OpenCart - click image to view

[![IMAGE ALT TEXT HERE](http://img.youtube.com/vi/ezS1jWoMmjc/0.jpg)](http://www.youtube.com/watch?v=ezS1jWoMmjc)
